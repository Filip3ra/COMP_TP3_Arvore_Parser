double funcao(int a, double b, char c) {
  int aa;
  double bb;
  int cc;
  int dd;
  aa = a + 2;
  bb = b*aa+1;
  cc = aa/bb-aa+b;
  dd = a+b+c+d*dd-cc*bb;
}
