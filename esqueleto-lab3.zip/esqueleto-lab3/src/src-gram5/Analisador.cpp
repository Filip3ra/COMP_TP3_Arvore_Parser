#include "Analisador.hpp"

int Analisador::calcula_ultimo_valor(Funcao *f, const vector<int> &params) {
   // Preencher aqui.
  return 0;
}
