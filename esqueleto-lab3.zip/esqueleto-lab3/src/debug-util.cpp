#include <iostream>
using namespace std;
void tab3(int tab) {
  for (int i = 0; i < 3*tab; ++i) {
    cerr << " ";
  }
}
